
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdlib.h>
#include "xil_types.h"
#include "xtmrctr.h"
#include "xparameters.h"

// Define MT19937 constants (32-bit RNG)
enum
{
    // Assumes W = 32 (omitting this)
    N = 624,
    M = 397,
    R = 31,
    A = 0x9908B0DF,

    F = 1812433253,

    U = 11,
    // Assumes D = 0xFFFFFFFF (omitting this)

    S = 7,
    B = 0x9D2C5680,

    T = 15,
    C = 0xEFC60000,

    L = 18,

    MASK_LOWER =  (1ull << R) - 1,
    MASK_UPPER = (1ull << R)
};

static uint32_t  mt[N];
static uint16_t  index;

#define macMinBE 			3		//Min Backoff Exponent
#define macMaxBE 			5		//Max Backoff Exponent
#define macMaxCSMABackoffs 	4
#define aUnitBackoffPeriod 	20 		//symbols
#define aMaxPHYPacketSize 	127		//defined in the standard
#define clockticksPerSymbol 2400 	//for a 150MHz clock
#define AXI_TIMER_1       	0 		// timer counter of the device to operate on
//#define RTXMODE			1 		//1=collision detection, 0=half duplex

//The Bust in/out to/from FPGA
struct __attribute__ ((__packed__)) GPIO {
	//Outputs
	uint8_t 	outCCAstart;
	uint8_t 	outValid;
	uint8_t 	outDone;
	uint8_t 	outExtra;
	uint16_t 	outTransmitted;
	uint16_t 	outData;

	//Inputs
	uint16_t	inData0;	// Seed
	uint16_t	inData1;	// Device Address
	uint16_t	inData2;	// b0:Start b1:in_valid b2:in_CCA b3:in_CCAvalid b4:in_CDenable b5:in_CDdetected_Ave b6:TransferData b7:PacketInfoDataReady
	uint16_t	inData3;	// Destination Address
};

uint8_t NB = 0;				//IEEE 802.15.4 : NB : the number of times the CSMA/CA was required to delay while attempting the current transmit!
uint8_t BE = macMinBE;		//IEEE 802.15.4 : BE : is the backoff exponent; how many slot periods a device must wait before attempting to assess the channel.
XTmrCtr TimerCounter;
uint16_t packet[aMaxPHYPacketSize];
uint8_t  packetLength;
uint8_t  newPacket = 1;    //If the packet is a new one
uint32_t nbTxTries = 30000;
uint32_t counter =0;
uint16_t DeviceAdd;
uint16_t DestinationAdd;
bool RTXMODE; 		//1=collision detection, 0=half duplex
//GPIO Address
volatile struct GPIO * const tom_gpio = (volatile struct GPIO *)0x44a00000; 

void resetCSMA();								//To reset CSMA algorithm
void generatePacket();							//generating a default packet
void backoff();									//backoff time delay
void delay(uint16_t backoffslots);				//generates delay for backoff time
void shortDelay(uint16_t backoffslots);			//
uint8_t CCA();									//Clear Channel Assessment
void transmitPacket();							//Transmit a packet
void updateCSMA();
void maxBackoffs();								//check for max backoff
bool detectCollisions();						//Check for collision
void Initialize(const uint32_t  seed);			//Initialization
uint32_t ExtractU32();
bool cd_enable();								//Is Collision detection requested!
bool in_Start();								//Start MAC
bool in_CCAvalid();								//Is CCA valid
bool in_CCA();									//read CCA
bool in_CD_Ave();								//read Collision Ave
bool in_TransferData();
void TransmiteData();
uint16_t FCS(uint8_t in_data,uint16_t old_FCS);//Generate FCS

int main()
{
	/* Initializes timer */
	XTmrCtr_Initialize(&TimerCounter, XPAR_AXI_TIMER_1_DEVICE_ID);
	XTmrCtr_SetOptions(&TimerCounter, AXI_TIMER_1, 0x0);
	XTmrCtr_Start(&TimerCounter, AXI_TIMER_1);

	packetLength = 112 + 2 + 2 + 2 + 2; //( 2bytes for frame control + 4 for address + 2 for FCS) <= 127

	//generatePacket();
	/* Main loop */
	while(1)
	{
		//Wait for start command! Update basic parameters if Start =0
		while(!in_Start()){
			Initialize(tom_gpio->inData0); //Initialize random seed to generate random backoff time
			DeviceAdd = tom_gpio->inData1; //Get device address
		}
		DestinationAdd = tom_gpio->inData3;//get destination address
		RTXMODE = cd_enable();			  // read CD mode. 0 : without collision detection, 1:with collision detection
		if(in_TransferData())			  // Start transmission?
		{
			TransmiteData();			  // Transmit data.
		}
		else
		{
			newPacket=0;
		}
	}
	return 0;
}


//CSMA transmit branch
void TransmiteData()
{
	if(newPacket==1)
	{
		//Only now generate new packet
		//generatePacket();
		resetCSMA();					 //reset CSMA parameters.
		newPacket=0;
	}
	backoff();							// backoff time
	if(CCA()==0)						//check channel
	{ //channel not free
		updateCSMA();					//update CSMA according to channel
		maxBackoffs();					//Check if the backoff time exceeds the maximum amount
	}
	else
	{
		//Channel is free

		transmitPacket();				//Transmite packet
		counter++;						//

		if (RTXMODE==0) //Without collision detection
		{	//Half Duplex
			 newPacket = 1;
		}
		else //Collision detection
		{
			if(detectCollisions())		//Check if collision has happened
			{
				updateCSMA();
				maxBackoffs();
				newPacket=0;
			}
			else
			{
				newPacket=1;
			}
		}
	}
}


bool in_TransferData()
{
	return 	(tom_gpio->inData2 & 0x0040);
}

bool in_Start()
{
	return 	(tom_gpio->inData2 & 0x0001);
}

//check if collision detection is selected
bool cd_enable()
{
	return (tom_gpio->inData2 & 0x0010);
}

//reset CSMA algorithm
void resetCSMA()
{
	// Reset CSMA parameters
	NB = 0;
	BE = macMinBE;
}


void updateCSMA()
{
	// Update CSMA parameters
	NB++;
	if (BE+1>macMaxBE){
		BE=macMaxBE;
	}
	else{
		BE++;
	}
}

//check for max backoff time
void maxBackoffs()
{
	// Check if maximum backoffs has been reached
	if(NB>macMaxCSMABackoffs){
		newPacket=1;
	}
	// else newPacket will remain 0
}

//backoff delay
void backoff()
{
	delay(ExtractU32() % (int)pow(2,BE));
}

void delay(uint16_t backoffslots)
{
	uint32_t reset_value = backoffslots*aUnitBackoffPeriod*clockticksPerSymbol;

	XTmrCtr_Reset(&TimerCounter, AXI_TIMER_1);
	while(XTmrCtr_GetValue(&TimerCounter, AXI_TIMER_1)<=reset_value){};

}

void shortDelay(uint16_t backoffslots)
{
	uint32_t reset_value = backoffslots;

	XTmrCtr_Reset(&TimerCounter, AXI_TIMER_1);
	while(XTmrCtr_GetValue(&TimerCounter, AXI_TIMER_1)<=reset_value){};

}

void generatePacket()
{
	uint8_t i;
	for (i=0; i<packetLength; i++)
	{
		packet[i] = i;
	}
}

//Perform CCA
uint8_t CCA()
{
	tom_gpio->outCCAstart = 1; // Reset CCA
	shortDelay(10); //delay to cross clock domains
	tom_gpio->outCCAstart = 0;
	while(!in_CCAvalid()){};
	return in_CCA();
}

//Read CCA signal
bool in_CCA()
{
	return (tom_gpio->inData2 & 0x0004);
}

// check for valid CCA
bool in_CCAvalid()
{
	return (tom_gpio->inData2 & 0x0008);
}

//writing a packet to PHY
void transmitPacket()
{

	uint8_t i;

	// Fill packet
	//........ Frame control
	packet[0] = 113;
	packet[1] = 100;
	//........ Address
	packet[2] =	(uint8_t)(DestinationAdd & 0x00FF);				//destination Add B0
	packet[3] = (uint8_t)((DestinationAdd>>8) & 0x00FF);		//destination Add B1
	packet[4] = (uint8_t)(DeviceAdd & 0x00FF);					//Source Add	B0
	packet[5] = (uint8_t)((DeviceAdd>>8) & 0x00FF);				//Source Add 	B1
	//........ Payload
	for (i = 0;i<packetLength - 6 - 2;i++)
		packet[i + 6] = i;
	//........ Compute FCS, Add FCS to the packet
	uint16_t fcs =0;
	for(i =0;i<packetLength - 2;i++)
		fcs = FCS(packet[i],fcs);

	packet[packetLength-2] = fcs & 0x00FF;
	packet[packetLength-1] = (fcs>>8) & 0x00FF;
	tom_gpio->outTransmitted = fcs;

	//Write Packet to FIFO
	tom_gpio->outData = 256; //send start signal for PHY
	tom_gpio->outValid = 1;
	tom_gpio->outValid = 0;
	tom_gpio->outData = packetLength; //send packet length for PHY
	tom_gpio->outValid = 1;
	tom_gpio->outValid = 0;

	for(i=0; i<packetLength; i++)
	{
		tom_gpio->outData = packet[i];
		tom_gpio->outValid = 1;
		tom_gpio->outValid = 0;
	}

}

//reading collision detection (without average)
bool detectCollisions()
{
	return in_CD_Ave();
}

//reading collision detection signal (AVE)
bool in_CD_Ave()
{
	return (tom_gpio->inData2 & 0x0020);
}


// Re-init with a given seed, generating random number
void Initialize(const uint32_t  seed)
{
    uint32_t  i;

    mt[0] = seed;

    for ( i = 1; i < N; i++ )
    {
        mt[i] = (F * (mt[i - 1] ^ (mt[i - 1] >> 30)) + i);
    }

    index = N;
}

static void Twist()
{
    uint32_t  i, x, xA;

    for ( i = 0; i < N; i++ )
    {
        x = (mt[i] & MASK_UPPER) + (mt[(i + 1) % N] & MASK_LOWER);

        xA = x >> 1;

        if ( x & 0x1 )
            xA ^= A;

        mt[i] = mt[(i + M) % N] ^ xA;
    }

    index = 0;
}

// Obtain a 32-bit random number
uint32_t ExtractU32()
{
    uint32_t  y;
    int       i = index;

    if ( index >= N )
    {
        Twist();
        i = index;
    }

    y = mt[i];
    index = i + 1;

    y ^= (mt[i] >> U);
    y ^= (y << S) & B;
    y ^= (y << T) & C;
    y ^= (y >> L);

    return y;
}

//Generating FCS bytes according to the standard
uint16_t FCS(uint8_t in_data,uint16_t old_FCS)
{
    uint16_t temp_FCS = old_FCS;
    uint8_t temp_data = in_data;
    int i;
    for(i =0;i<8;i++)
    {
        bool b15 = (temp_FCS & 0x0001) ^ ((temp_data>>i) & 0x0001);
        bool b3 = b15 ^ ((temp_FCS>>4) & 0x0001);
        bool b10 = b15 ^ ((temp_FCS>>11) & 0x0001);
        temp_FCS = temp_FCS >> 1;

        if(b15)
            temp_FCS = temp_FCS | 0x8000;
        else
            temp_FCS = temp_FCS & 0x7FFF;

        if(b3)
            temp_FCS = temp_FCS | 0x0008;
        else
            temp_FCS = temp_FCS & 0xFFF7;

        if(b10)
            temp_FCS = temp_FCS | 0x0400;
        else
            temp_FCS = temp_FCS & 0xFBFF;

    }
    return temp_FCS;
}

